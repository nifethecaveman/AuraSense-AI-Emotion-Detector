start luajit.exe certificate.txt
